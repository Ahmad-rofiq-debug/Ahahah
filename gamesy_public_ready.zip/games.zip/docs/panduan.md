# Panduan Lengkap

## 1. Menjalankan Lokal
1. Install Python 3.10+
2. Buat virtualenv
3. Install dependency
4. Jalankan `python app/app.py`

## 2. Login
- Admin: `admin / admin123`
- User: `budi / budi12345`

## 3. Alur User
- login
- buka daftar alat
- ajukan peminjaman
- lihat status pada halaman pengajuan
- jika disetujui, ajukan pengembalian

## 4. Alur Admin
- login admin
- kelola alat
- upload gambar alat
- lihat QR alat
- buka persetujuan
- setujui/tolak pengajuan
- cek log aktivitas
- aktifkan Telegram

## 5. Edit Tampilan
CSS ada di:
- `app/static/css/style.css`

## 6. Deploy
Gunakan hosting yang mendukung Python seperti:
- Render
- Railway
- VPS Ubuntu + Gunicorn + Nginx

## 7. HTTPS dan Kamera
Kamera browser umumnya butuh HTTPS jika online public.

## 8. Backup Database
Database SQLite ada di:
- `database/gudang.db`

Backup cukup copy file tersebut saat aplikasi mati.

