
# -*- coding: utf-8 -*-
import os
import io
import json
import base64
import sqlite3
import secrets
import logging
import ipaddress
import urllib.request
import urllib.parse
from datetime import date, datetime, timezone
from functools import wraps

from flask import (
    Flask, request, redirect, url_for, session, render_template,
    flash, g, abort, jsonify, send_from_directory
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(BASE_DIR)
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(PROJECT_DIR, "database", "gudang.db"))
SECRET_KEY_PATH = os.path.join(PROJECT_DIR, "config", "secret.key")
TELEGRAM_CONFIG_PATH = os.path.join(PROJECT_DIR, "config", "telegram.json")
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
TOOL_IMG_DIR = os.path.join(BASE_DIR, "static", "img", "tools")
MAX_STOK = 1000000
MAX_PASSWORD = 128
MAX_PINJAM_HARI = 365
MAX_NAMA_USER = 100
MAX_NAMA_ALAT = 150
MAX_KODE_ALAT = 50
MAX_KEPERLUAN = 500
ALLOWED_IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "webp", "gif"}
PLACEHOLDER_MAP = {
    "router": "router.png",
    "switch": "switch.png",
    "kabel": "kabel_lan.png",
    "lan": "kabel_lan.png",
    "crimping": "crimping_tool.png",
    "access point": "access_point.png",
    "ap": "access_point.png",
    "server": "server_rack.png",
}

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

def load_or_create_secret_key():
    env_key = os.environ.get("FLASK_SECRET_KEY")
    if env_key:
        return env_key
    os.makedirs(os.path.dirname(SECRET_KEY_PATH), exist_ok=True)
    if os.path.exists(SECRET_KEY_PATH):
        val = open(SECRET_KEY_PATH, "r", encoding="utf-8").read().strip()
        if val:
            return val
    key = secrets.token_hex(32)
    with open(SECRET_KEY_PATH, "w", encoding="utf-8") as f:
        f.write(key)
    return key

app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = load_or_create_secret_key()
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("FLASK_ENV", "").lower() == "production"
app.config["SESSION_COOKIE_NAME"] = "gudang_session"
app.config["MAX_CONTENT_LENGTH"] = 4 * 1024 * 1024

def telegram_config():
    if not os.path.exists(TELEGRAM_CONFIG_PATH):
        return {"enabled": False, "bot_token": "", "chat_id": ""}
    try:
        return json.load(open(TELEGRAM_CONFIG_PATH, "r", encoding="utf-8"))
    except Exception:
        return {"enabled": False, "bot_token": "", "chat_id": ""}

def send_telegram_message(message):
    cfg = telegram_config()
    if not cfg.get("enabled") or not cfg.get("bot_token") or not cfg.get("chat_id"):
        return False
    try:
        token = cfg["bot_token"]
        chat_id = str(cfg["chat_id"])
        data = urllib.parse.urlencode({"chat_id": chat_id, "text": message}).encode()
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{token}/sendMessage", data=data, method="POST"
        )
        urllib.request.urlopen(req, timeout=8).read()
        return True
    except Exception as e:
        logger.warning("Gagal kirim telegram: %s", e)
        return False

@app.after_request
def add_security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self' https://cdn.jsdelivr.net; img-src 'self' data: https:; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' data:;"
    )
    return response

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH, timeout=10.0)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
        g.db.execute("PRAGMA busy_timeout = 10000")
        g.db.execute("PRAGMA journal_mode = WAL")
    return g.db

@app.teardown_appcontext
def teardown_db(exc):
    db = g.pop("db", None)
    if db:
        db.close()

def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10.0)
    try:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA busy_timeout = 10000")
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nama TEXT UNIQUE NOT NULL COLLATE NOCASE,
                password TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('admin','user'))
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS alat (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nama TEXT NOT NULL,
                kode TEXT NOT NULL UNIQUE,
                status TEXT NOT NULL CHECK(status IN ('tersedia','rusak')),
                stok INTEGER NOT NULL DEFAULT 1 CHECK(stok >= 0),
                spesifikasi TEXT DEFAULT '',
                lokasi TEXT DEFAULT '',
                gambar TEXT DEFAULT '',
                qr_code TEXT DEFAULT '',
                barcode_text TEXT DEFAULT ''
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS peminjaman (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                id_user INTEGER NOT NULL,
                id_alat INTEGER NOT NULL,
                jenis TEXT NOT NULL CHECK(jenis IN ('pinjam','kembali')),
                keperluan TEXT,
                tanggal_pinjam TEXT,
                tanggal_kembali TEXT,
                status TEXT NOT NULL CHECK(status IN ('pending','disetujui','ditolak','selesai')),
                id_peminjaman_asal INTEGER,
                dibuat_pada TEXT NOT NULL,
                FOREIGN KEY(id_user) REFERENCES users(id),
                FOREIGN KEY(id_alat) REFERENCES alat(id) ON DELETE RESTRICT,
                FOREIGN KEY(id_peminjaman_asal) REFERENCES peminjaman(id)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS aktivitas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                waktu TEXT NOT NULL,
                user_nama TEXT NOT NULL,
                aksi TEXT NOT NULL,
                detail TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS idx_pinjam_pending
            ON peminjaman(id_user,id_alat)
            WHERE jenis='pinjam' AND status='pending'
        """)
        conn.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS idx_kembali_pending
            ON peminjaman(id_peminjaman_asal)
            WHERE jenis='kembali' AND status='pending'
        """)
        # migrations ringan
        cols = [r[1] for r in conn.execute("PRAGMA table_info(alat)").fetchall()]
        for name, ddl in [
            ("spesifikasi", "ALTER TABLE alat ADD COLUMN spesifikasi TEXT DEFAULT ''"),
            ("lokasi", "ALTER TABLE alat ADD COLUMN lokasi TEXT DEFAULT ''"),
            ("gambar", "ALTER TABLE alat ADD COLUMN gambar TEXT DEFAULT ''"),
            ("qr_code", "ALTER TABLE alat ADD COLUMN qr_code TEXT DEFAULT ''"),
            ("barcode_text", "ALTER TABLE alat ADD COLUMN barcode_text TEXT DEFAULT ''"),
        ]:
            if name not in cols:
                conn.execute(ddl)
        conn.commit()
        if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0] == 0:
            admin_name = os.environ.get("ADMIN_USERNAME", "admin").strip() or "admin"
            admin_password = os.environ.get("ADMIN_PASSWORD", "").strip()
            if not admin_password:
                # Development fallback only. Set ADMIN_PASSWORD in production.
                admin_password = secrets.token_urlsafe(18)
                logger.warning("ADMIN_PASSWORD belum diatur. Password admin sementara dibuat: %s", admin_password)
            conn.execute("INSERT INTO users (nama,password,role) VALUES (?,?,?)",
                         (admin_name, generate_password_hash(admin_password), "admin"))
            if os.environ.get("SEED_DEMO_USER", "").lower() in ("1", "true", "yes"):
                demo_password = os.environ.get("DEMO_USER_PASSWORD", "budi12345")
                conn.execute("INSERT INTO users (nama,password,role) VALUES (?,?,?)",
                             ("budi", generate_password_hash(demo_password), "user"))
            samples = [
                ("Router Mikrotik", "TKJ-ROUTER-001", "tersedia", 3, "Routerboard untuk praktik routing", "Lab Jaringan", "img/tools/router.png"),
                ("Switch 24 Port", "TKJ-SWITCH-002", "tersedia", 2, "Switch manageable 24 port gigabit", "Lab Jaringan", "img/tools/switch.png"),
                ("Crimping Tool", "TKJ-CRIMP-003", "tersedia", 5, "Tang crimping RJ45", "Gudang TKJ", "img/tools/crimping_tool.png"),
                ("Kabel LAN Tester", "TKJ-LAN-004", "tersedia", 4, "Tester kabel jaringan", "Gudang TKJ", "img/tools/kabel_lan.png"),
            ]
            for nama, kode, status, stok, spek, lokasi, gambar in samples:
                code = make_qr_data_url(f"ALAT|{kode}|{nama}")
                conn.execute("""INSERT INTO alat (nama,kode,status,stok,spesifikasi,lokasi,gambar,qr_code,barcode_text)
                             VALUES (?,?,?,?,?,?,?,?,?)""", (nama,kode,status,stok,spek,lokasi,gambar,code,kode))
            conn.commit()
    finally:
        conn.close()

def get_csrf_token():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(32)
    return session["csrf_token"]

app.jinja_env.globals["csrf_token"] = get_csrf_token

@app.before_request
def csrf_protect():
    if request.method == "POST":
        tf = request.form.get("csrf_token", "")
        ts = session.get("csrf_token", "")
        if not tf or not ts or not secrets.compare_digest(tf, ts):
            abort(400, description="CSRF tidak valid. Muat ulang halaman lalu coba lagi.")

def valid_text(value, max_length):
    return isinstance(value, str) and bool(value.strip()) and len(value) <= max_length

def parse_non_negative_int(value, maximum=MAX_STOK):
    try:
        x = int(value)
        if 0 <= x <= maximum:
            return x
    except Exception:
        pass
    return None

def status_label(status):
    return {
        "pending": "Menunggu",
        "disetujui": "Disetujui",
        "ditolak": "Ditolak",
        "selesai": "Selesai",
        "tersedia": "Tersedia",
        "rusak": "Rusak",
    }.get(status, status)

app.jinja_env.globals["status_label"] = status_label

def current_user():
    if not session.get("user_id"):
        return None
    db = get_db()
    return db.execute("SELECT id,nama,role FROM users WHERE id=?", (session["user_id"],)).fetchone()

def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper

def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("user_id") or session.get("role") != "admin":
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper

def user_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return wrapper

def log_activity(aksi, detail):
    try:
        db = get_db()
        db.execute(
            "INSERT INTO aktivitas (waktu,user_nama,aksi,detail) VALUES (?,?,?,?)",
            (datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), session.get("nama", "system"), aksi, detail)
        )
        db.commit()
    except Exception:
        logger.exception("Gagal menulis log")

def tool_image_by_name(nama):
    n = (nama or "").lower()
    for k,v in PLACEHOLDER_MAP.items():
        if k in n:
            return f"img/tools/{v}"
    return "img/tools/default_tool.png"

def make_qr_data_url(text):
    try:
        import qrcode
        img = qrcode.make(text)
        bio = io.BytesIO()
        img.save(bio, format="PNG")
        return "data:image/png;base64," + base64.b64encode(bio.getvalue()).decode()
    except Exception:
        svg = f"""<svg xmlns='http://www.w3.org/2000/svg' width='220' height='220'>
        <rect width='100%' height='100%' fill='white'/><rect x='20' y='20' width='180' height='180' fill='none' stroke='black' stroke-width='6'/>
        <text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' font-size='18'>QR {text[:12]}</text></svg>"""
        return "data:image/svg+xml;base64," + base64.b64encode(svg.encode()).decode()

def allowed_file(filename):
    return "." in filename and filename.rsplit(".",1)[1].lower() in ALLOWED_IMAGE_EXTENSIONS

def save_upload(fs):
    if not fs or not fs.filename:
        return ""
    if not allowed_file(fs.filename):
        return ""
    ext = fs.filename.rsplit(".",1)[1].lower()
    name = secure_filename(fs.filename.rsplit(".",1)[0])[:40]
    out = f"{name}_{secrets.token_hex(6)}.{ext}"
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    fs.save(os.path.join(UPLOAD_DIR, out))
    return f"uploads/{out}"

def fetch_peminjaman(where_sql="", params=()):
    q = f"""
    SELECT peminjaman.*, users.nama AS nama_user, alat.nama AS nama_alat,
           alat.kode AS kode_alat, alat.stok AS stok, alat.status AS status_alat
    FROM peminjaman
    JOIN users ON users.id = peminjaman.id_user
    JOIN alat ON alat.id = peminjaman.id_alat
    {where_sql}
    ORDER BY peminjaman.id DESC
    """
    return get_db().execute(q, params).fetchall()

@app.route("/")
def index():
    if session.get("user_id"):
        if session.get("role") == "admin":
            return redirect(url_for("dashboard"))
        return redirect(url_for("user_alat"))
    return redirect(url_for("login"))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        nama = request.form.get("nama","").strip()
        password = request.form.get("password","")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE nama=?", (nama,)).fetchone()
        if user and check_password_hash(user["password"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["nama"] = user["nama"]
            session["role"] = user["role"]
            get_csrf_token()
            flash("Login berhasil.", "ok")
            return redirect(url_for("dashboard" if user["role"]=="admin" else "user_alat"))
        flash("Nama user atau password salah.", "error")
    return render_template("login.html", page_title="Login")

@app.route("/logout", methods=["POST"])
@login_required
def logout():
    session.clear()
    flash("Anda telah logout.", "ok")
    return redirect(url_for("login"))

@app.route("/dashboard")
@admin_required
def dashboard():
    db = get_db()
    stats = {
        "alat": db.execute("SELECT COUNT(*) FROM alat").fetchone()[0],
        "stok": db.execute("SELECT COALESCE(SUM(stok),0) FROM alat").fetchone()[0],
        "pending": db.execute("SELECT COUNT(*) FROM peminjaman WHERE status='pending'").fetchone()[0],
        "user": db.execute("SELECT COUNT(*) FROM users").fetchone()[0],
    }
    recent = db.execute("SELECT * FROM aktivitas ORDER BY id DESC LIMIT 8").fetchall()
    return render_template("dashboard.html", stats=stats, recent=recent, page_title="Dashboard")

@app.route("/admin/alat")
@admin_required
def admin_alat():
    alat = get_db().execute("SELECT * FROM alat ORDER BY nama").fetchall()
    return render_template("alat_list.html", alat=alat, page_title="Data Alat")

@app.route("/admin/alat/form", methods=["GET","POST"])
@app.route("/admin/alat/<int:alat_id>/form", methods=["GET","POST"])
@admin_required
def admin_alat_form(alat_id=None):
    db = get_db()
    editing = db.execute("SELECT * FROM alat WHERE id=?", (alat_id,)).fetchone() if alat_id else None
    if alat_id and not editing:
        flash("Alat tidak ditemukan.", "error")
        return redirect(url_for("admin_alat"))
    if request.method == "POST":
        nama = request.form.get("nama","").strip()
        kode = request.form.get("kode","").strip().upper()
        status = request.form.get("status","tersedia")
        stok = parse_non_negative_int(request.form.get("stok"))
        spesifikasi = request.form.get("spesifikasi","").strip()[:2000]
        lokasi = request.form.get("lokasi","").strip()[:120]
        barcode_text = request.form.get("barcode_text","").strip()[:120] or kode
        if not valid_text(nama, MAX_NAMA_ALAT) or not valid_text(kode, MAX_KODE_ALAT) or stok is None:
            flash("Data alat belum valid.", "error")
            return render_template("alat_form.html", editing=editing, page_title="Form Alat")
        if status == "rusak":
            stok = 0
        gambar = editing["gambar"] if editing else ""
        up = request.files.get("gambar_file")
        saved = save_upload(up)
        if saved:
            gambar = saved
        elif not gambar:
            gambar = tool_image_by_name(nama)
        qr_code = make_qr_data_url(f"ALAT|{kode}|{nama}")
        try:
            if editing:
                db.execute("""UPDATE alat SET nama=?,kode=?,status=?,stok=?,spesifikasi=?,lokasi=?,gambar=?,qr_code=?,barcode_text=? WHERE id=?""",
                           (nama,kode,status,stok,spesifikasi,lokasi,gambar,qr_code,barcode_text,alat_id))
                detail = f"Ubah alat {nama} ({kode})"
            else:
                db.execute("""INSERT INTO alat (nama,kode,status,stok,spesifikasi,lokasi,gambar,qr_code,barcode_text)
                           VALUES (?,?,?,?,?,?,?,?,?)""",
                           (nama,kode,status,stok,spesifikasi,lokasi,gambar,qr_code,barcode_text))
                detail = f"Tambah alat {nama} ({kode})"
            db.commit()
            log_activity("alat", detail)
            flash("Data alat disimpan.", "ok")
            return redirect(url_for("admin_alat"))
        except sqlite3.IntegrityError:
            db.rollback()
            flash("Kode alat sudah dipakai.", "error")
    return render_template("alat_form.html", editing=editing, page_title="Form Alat")

@app.route("/admin/alat/<int:alat_id>/delete", methods=["POST"])
@admin_required
def admin_alat_delete(alat_id):
    db = get_db()
    try:
        alat = db.execute("SELECT * FROM alat WHERE id=?", (alat_id,)).fetchone()
        cur = db.execute("DELETE FROM alat WHERE id=?", (alat_id,))
        if cur.rowcount:
            db.commit()
            log_activity("alat", f"Hapus alat {alat['nama'] if alat else alat_id}")
            flash("Alat dihapus.", "ok")
        else:
            flash("Alat tidak ditemukan.", "error")
    except sqlite3.IntegrityError:
        db.rollback()
        flash("Alat tidak bisa dihapus karena punya riwayat peminjaman.", "error")
    return redirect(url_for("admin_alat"))

@app.route("/admin/persetujuan")
@admin_required
def admin_persetujuan():
    return render_template("persetujuan.html", pending=fetch_peminjaman("WHERE peminjaman.status='pending'"),
                           riwayat=fetch_peminjaman("WHERE peminjaman.status!='pending'"), page_title="Persetujuan")

@app.route("/admin/persetujuan/<int:p_id>/<keputusan>", methods=["POST"])
@admin_required
def admin_persetujuan_decide(p_id, keputusan):
    if keputusan not in ("setuju","tolak"):
        abort(400)
    db = get_db()
    try:
        db.execute("BEGIN IMMEDIATE")
        p = db.execute("SELECT * FROM peminjaman WHERE id=?", (p_id,)).fetchone()
        if not p or p["status"] != "pending":
            db.rollback()
            flash("Pengajuan sudah diproses atau tidak ditemukan.", "error")
            return redirect(url_for("admin_persetujuan"))
        if keputusan == "tolak":
            db.execute("UPDATE peminjaman SET status='ditolak' WHERE id=?", (p_id,))
            db.commit()
            log_activity("persetujuan", f"Tolak pengajuan #{p_id}")
            send_telegram_message(f"Pengajuan #{p_id} ditolak admin.")
            flash("Pengajuan ditolak.", "ok")
            return redirect(url_for("admin_persetujuan"))
        if p["jenis"] == "pinjam":
            cur = db.execute("UPDATE alat SET stok=stok-1 WHERE id=? AND stok>0 AND status='tersedia'", (p["id_alat"],))
            if cur.rowcount == 0:
                db.rollback()
                flash("Gagal menyetujui: stok habis atau alat rusak.", "error")
                return redirect(url_for("admin_persetujuan"))
            db.execute("UPDATE peminjaman SET status='disetujui' WHERE id=?", (p_id,))
            db.commit()
            log_activity("persetujuan", f"Setujui peminjaman #{p_id}")
            send_telegram_message(f"Peminjaman disetujui. Pengajuan #{p_id}.")
            flash("Peminjaman disetujui, stok dikurangi.", "ok")
            return redirect(url_for("admin_persetujuan"))
        if p["jenis"] != "kembali":
            db.rollback()
            flash("Jenis pengajuan tidak valid.", "error")
            return redirect(url_for("admin_persetujuan"))
        asal = db.execute("SELECT * FROM peminjaman WHERE id=?", (p["id_peminjaman_asal"],)).fetchone() if p["id_peminjaman_asal"] else None
        if (not asal or asal["jenis"] != "pinjam" or asal["status"] != "disetujui" or asal["id_alat"] != p["id_alat"] or asal["id_user"] != p["id_user"]):
            db.rollback()
            flash("Data pengembalian tidak valid atau tidak konsisten.", "error")
            return redirect(url_for("admin_persetujuan"))
        cur = db.execute("UPDATE alat SET stok=stok+1 WHERE id=? AND stok < ?", (p["id_alat"], MAX_STOK))
        if cur.rowcount != 1:
            db.rollback()
            flash("Pengembalian gagal: alat tidak ditemukan atau stok sudah maksimum.", "error")
            return redirect(url_for("admin_persetujuan"))
        db.execute("UPDATE peminjaman SET status='selesai' WHERE id=?", (p_id,))
        db.execute("UPDATE peminjaman SET status='selesai' WHERE id=?", (asal["id"],))
        db.commit()
        log_activity("persetujuan", f"Setujui pengembalian #{p_id}")
        send_telegram_message(f"Pengembalian disetujui. Pengajuan #{p_id}.")
        flash("Pengembalian disetujui, stok ditambahkan.", "ok")
    except sqlite3.OperationalError:
        db.rollback()
        flash("Database sedang sibuk. Silakan coba lagi.", "error")
    return redirect(url_for("admin_persetujuan"))

@app.route("/admin/user")
@admin_required
def admin_user():
    users = get_db().execute("SELECT id,nama,role FROM users ORDER BY nama").fetchall()
    return render_template("user_list.html", users=users, page_title="Pengguna")

@app.route("/admin/user/form", methods=["GET","POST"])
@app.route("/admin/user/<int:user_id>/form", methods=["GET","POST"])
@admin_required
def admin_user_form(user_id=None):
    db = get_db()
    editing = db.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone() if user_id else None
    if request.method == "POST":
        nama = request.form.get("nama","").strip()
        password = request.form.get("password","")
        role = request.form.get("role","user")
        if not valid_text(nama, MAX_NAMA_USER) or role not in ("admin","user"):
            flash("Data user tidak valid.", "error")
        elif editing:
            if password:
                db.execute("UPDATE users SET nama=?,password=?,role=? WHERE id=?", (nama,generate_password_hash(password),role,user_id))
            else:
                db.execute("UPDATE users SET nama=?,role=? WHERE id=?", (nama,role,user_id))
            db.commit()
            flash("User diperbarui.", "ok")
            return redirect(url_for("admin_user"))
        else:
            if len(password) < 8:
                flash("Password minimal 8 karakter.", "error")
            else:
                db.execute("INSERT INTO users (nama,password,role) VALUES (?,?,?)", (nama,generate_password_hash(password),role))
                db.commit()
                flash("User ditambahkan.", "ok")
                return redirect(url_for("admin_user"))
    return render_template("user_form.html", editing=editing, page_title="Form User")

@app.route("/admin/user/<int:user_id>/delete", methods=["POST"])
@admin_required
def admin_user_delete(user_id):
    if user_id == session.get("user_id"):
        flash("Tidak bisa menghapus akun sendiri.", "error")
        return redirect(url_for("admin_user"))
    db = get_db()
    db.execute("DELETE FROM users WHERE id=?", (user_id,))
    db.commit()
    flash("User dihapus.", "ok")
    return redirect(url_for("admin_user"))

@app.route("/admin/log")
@admin_required
def admin_log():
    logs = get_db().execute("SELECT * FROM aktivitas ORDER BY id DESC LIMIT 200").fetchall()
    return render_template("log.html", logs=logs, page_title="Log Aktivitas")

@app.route("/admin/telegram", methods=["GET","POST"])
@admin_required
def admin_telegram():
    cfg = telegram_config()
    if request.method == "POST":
        cfg = {
            "enabled": bool(request.form.get("enabled")),
            "bot_token": request.form.get("bot_token","").strip(),
            "chat_id": request.form.get("chat_id","").strip(),
        }
        os.makedirs(os.path.dirname(TELEGRAM_CONFIG_PATH), exist_ok=True)
        json.dump(cfg, open(TELEGRAM_CONFIG_PATH,"w",encoding="utf-8"), ensure_ascii=False, indent=2)
        flash("Pengaturan Telegram disimpan.", "ok")
        return redirect(url_for("admin_telegram"))
    return render_template("telegram.html", cfg=cfg, page_title="Telegram Bot")

@app.route("/user/alat")
@user_required
def user_alat():
    alat = get_db().execute("SELECT * FROM alat ORDER BY nama").fetchall()
    return render_template("user_alat.html", alat=alat, page_title="Alat Tersedia")

@app.route("/user/alat/<int:alat_id>/pinjam", methods=["GET","POST"])
@user_required
def user_pinjam_form(alat_id):
    db = get_db()
    alat = db.execute("SELECT * FROM alat WHERE id=?", (alat_id,)).fetchone()
    if not alat:
        flash("Alat tidak ditemukan.", "error")
        return redirect(url_for("user_alat"))
    if request.method == "POST":
        keperluan = request.form.get("keperluan","").strip()
        tgl_pinjam = request.form.get("tanggal_pinjam","")
        tgl_kembali = request.form.get("tanggal_kembali","")
        try:
            dp = datetime.strptime(tgl_pinjam, "%Y-%m-%d").date()
            dk = datetime.strptime(tgl_kembali, "%Y-%m-%d").date()
            if dp < date.today() or dk < dp or (dk-dp).days > MAX_PINJAM_HARI:
                raise ValueError
        except Exception:
            flash("Tanggal tidak valid.", "error")
            return render_template("pinjam_form.html", alat=alat, hari_ini=date.today().isoformat(), page_title="Ajukan Peminjaman")
        try:
            db.execute("BEGIN IMMEDIATE")
            alat_now = db.execute("SELECT status,stok FROM alat WHERE id=?", (alat_id,)).fetchone()
            if not alat_now or alat_now["status"] != "tersedia" or alat_now["stok"] <= 0:
                db.rollback()
                flash("Alat tidak tersedia.", "error")
                return redirect(url_for("user_alat"))
            db.execute("""INSERT INTO peminjaman (id_user,id_alat,jenis,keperluan,tanggal_pinjam,tanggal_kembali,status,dibuat_pada)
                       VALUES (?,?,?,?,?,?, 'pending', ?)""",
                       (session["user_id"], alat_id, "pinjam", keperluan, tgl_pinjam, tgl_kembali, datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")))
            db.commit()
            log_activity("pinjam", f"Pengajuan pinjam {alat['nama']}")
            send_telegram_message(f"Pengajuan peminjaman baru: {session.get('nama')} - {alat['nama']}")
            flash("Pengajuan peminjaman berhasil dikirim.", "ok")
            return redirect(url_for("user_pengajuan"))
        except sqlite3.IntegrityError:
            db.rollback()
            flash("Pengajuan pending untuk alat ini sudah ada.", "error")
    return render_template("pinjam_form.html", alat=alat, hari_ini=date.today().isoformat(), page_title="Ajukan Peminjaman")

@app.route("/user/pengajuan")
@user_required
def user_pengajuan():
    db = get_db()
    rows = db.execute("""SELECT peminjaman.*, alat.nama AS nama_alat, alat.kode AS kode_alat
                         FROM peminjaman JOIN alat ON alat.id=peminjaman.id_alat
                         WHERE peminjaman.id_user=? ORDER BY peminjaman.id DESC""", (session["user_id"],)).fetchall()
    pengajuan=[]
    for r in rows:
        x=dict(r)
        if x["jenis"]=="pinjam" and x["status"]=="disetujui":
            pending_ret = db.execute("SELECT id FROM peminjaman WHERE id_peminjaman_asal=? AND jenis='kembali' AND status='pending'", (x["id"],)).fetchone()
            x["has_pending_return"]=bool(pending_ret)
        else:
            x["has_pending_return"]=False
        pengajuan.append(x)
    return render_template("pengajuan.html", pengajuan=pengajuan, page_title="Pengajuan Saya")

@app.route("/user/pengajuan/<int:p_id>/kembali", methods=["POST"])
@user_required
def user_kembalikan(p_id):
    db = get_db()
    try:
        db.execute("BEGIN IMMEDIATE")
        asal = db.execute("SELECT * FROM peminjaman WHERE id=? AND id_user=?", (p_id, session["user_id"])).fetchone()
        if not asal or asal["jenis"] != "pinjam" or asal["status"] != "disetujui":
            db.rollback()
            flash("Data pengembalian tidak valid.", "error")
            return redirect(url_for("user_pengajuan"))
        pending_ret = db.execute("SELECT id FROM peminjaman WHERE id_peminjaman_asal=? AND jenis='kembali' AND status='pending'", (p_id,)).fetchone()
        if pending_ret:
            db.rollback()
            flash("Pengajuan pengembalian sudah ada.", "error")
            return redirect(url_for("user_pengajuan"))
        db.execute("""INSERT INTO peminjaman (id_user,id_alat,jenis,keperluan,tanggal_pinjam,tanggal_kembali,status,id_peminjaman_asal,dibuat_pada)
                   VALUES (?,?,?,?,? ,?,'pending',?,?)""",
                   (session["user_id"], asal["id_alat"], "kembali", asal["keperluan"] or "Pengembalian", asal["tanggal_pinjam"], date.today().isoformat(), asal["id"], datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")))
        db.commit()
        log_activity("kembali", f"Ajukan pengembalian #{p_id}")
        send_telegram_message(f"Pengajuan pengembalian: {session.get('nama')} - #{p_id}")
        flash("Pengajuan pengembalian dikirim.", "ok")
    except sqlite3.IntegrityError:
        db.rollback()
        flash("Pengajuan pengembalian sudah pending.", "error")
    return redirect(url_for("user_pengajuan"))

@app.route("/user/profil", methods=["GET","POST"])
@user_required
def user_profil():
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
    if request.method == "POST":
        nama = request.form.get("nama","").strip()
        oldp = request.form.get("old_password","")
        newp = request.form.get("new_password","")
        if newp:
            if not check_password_hash(user["password"], oldp):
                flash("Password lama salah.", "error")
                return render_template("profil.html", user=user, page_title="Profil")
            db.execute("UPDATE users SET nama=?, password=? WHERE id=?", (nama, generate_password_hash(newp), session["user_id"]))
        else:
            db.execute("UPDATE users SET nama=? WHERE id=?", (nama, session["user_id"]))
        db.commit()
        session["nama"]=nama
        flash("Profil berhasil diperbarui.", "ok")
        return redirect(url_for("user_profil"))
    return render_template("profil.html", user=user, page_title="Profil")

@app.route("/scan")
@login_required
def scan_page():
    return render_template("scan.html", page_title="Scan QR / Barcode")

@app.route("/scan/result")
@login_required
def scan_result():
    code = request.args.get("code","").strip()
    alat = get_db().execute("SELECT * FROM alat WHERE kode=? OR barcode_text=?", (code, code)).fetchone()
    return render_template("scan_result.html", code=code, alat=alat, page_title="Hasil Scan")

@app.route("/api/alat/<int:alat_id>/qr")
@login_required
def alat_qr(alat_id):
    alat = get_db().execute("SELECT id,nama,kode,qr_code FROM alat WHERE id=?", (alat_id,)).fetchone()
    if not alat:
        abort(404)
    return jsonify({"id": alat["id"], "nama": alat["nama"], "kode": alat["kode"], "qr_code": alat["qr_code"]})

@app.route("/health")
def health():
    return {"ok": True, "time": datetime.now(timezone.utc).isoformat()}

# Initialize the database both for local execution and WSGI servers such as Gunicorn.
init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=os.environ.get("FLASK_DEBUG")=="1")
