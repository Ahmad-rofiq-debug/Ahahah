# Aplikasi Peminjaman Alat TKJ

Versi ini adalah perapihan dari aplikasi Flask lama dengan:
- route lama utama tetap dipertahankan
- login screen baru yang lebih estetik
- data alat dengan gambar
- upload gambar alat
- QR alat dibuat sendiri oleh aplikasi
- halaman scan QR/barcode dengan kamera browser
- approval admin aman dari stok negatif
- log aktivitas
- pengaturan Telegram bot
- struktur folder rapi

## Struktur Folder
- `app/app.py`
- `app/templates/`
- `app/static/css/`
- `app/static/img/tools/`
- `app/static/uploads/`
- `database/`
- `config/telegram.json`
- `docs/panduan.md`

## Akun Default
- admin / admin123
- budi / budi12345

## Install
```bash
python -m venv .venv
# windows
.venv\Scripts\activate
# linux/mac
source .venv/bin/activate

pip install flask werkzeug qrcode pillow gunicorn
python app/app.py
```

Buka:
- `http://127.0.0.1:5000`

## Deploy Public (sudah disiapkan)

### Render
Project ini sudah dilengkapi:
- `requirements.txt`
- `Procfile`
- `render.yaml`
- `wsgi.py`
- database otomatis diinisialisasi saat Gunicorn berjalan
- `FLASK_SECRET_KEY` dapat dibuat sebagai environment variable
- `ADMIN_USERNAME` dan `ADMIN_PASSWORD` dapat diatur tanpa menulis password di kode

Cara:
1. Upload project ke GitHub.
2. Di Render pilih **New → Blueprint** dan pilih repository tersebut.
3. Render akan membaca `render.yaml`.
4. Isi `ADMIN_USERNAME` dan `ADMIN_PASSWORD` saat diminta.
5. Deploy.
6. Buka URL HTTPS yang diberikan Render.

### Catatan penting
- Jangan gunakan password admin bawaan untuk website public.
- Jangan upload `config/secret.key` atau token Telegram ke GitHub.
- SQLite disimpan di `/var/data/gudang.db` pada konfigurasi Render dan membutuhkan persistent disk pada layanan yang mendukungnya.
- Kamera QR/barcode membutuhkan HTTPS dan izin kamera browser.


### Opsi Render
Start command:
```bash
gunicorn app.app:app
```

Tambahkan environment variable:
- `FLASK_ENV=production`
- `FLASK_SECRET_KEY=isi-random-panjang`

### Opsi Railway
Start command sama:
```bash
gunicorn app.app:app
```

## Telegram Bot
Isi file `config/telegram.json`:
```json
{
  "enabled": true,
  "bot_token": "ISI_BOT_TOKEN",
  "chat_id": "ISI_CHAT_ID"
}
```

Atau atur lewat menu admin Telegram.

## Fitur Scan Kamera
Halaman `/scan` memakai kamera browser.
Agar kamera jalan:
- pakai HTTPS jika dihosting
- izinkan permission camera
- jika tidak didukung, input manual tetap tersedia

## Upload Gambar
Masuk menu admin alat lalu edit/tambah alat.
File akan masuk ke:
- `app/static/uploads/`

## Catatan QR / Barcode
- QR dibuat aplikasi sendiri saat alat dibuat atau diubah
- barcode text disimpan di field `barcode_text`
- scan akan mencari ke `kode` atau `barcode_text`

## Keamanan Approval
Approval admin memakai transaksi dan pengurangan stok atomik:
- `BEGIN IMMEDIATE`
- `UPDATE alat SET stok = stok - 1 WHERE id=? AND stok > 0`

Ini mencegah stok negatif saat dua admin approve bersamaan.

## Edit Kode
File utama:
- `app/app.py`

Jika ingin memecah lebih lanjut:
- route auth
- route admin
- route user
- util database
bisa dipindahkan ke blueprint.

## Kekurangan yang Perlu Anda Tahu
- Pengiriman Telegram butuh internet saat aplikasi berjalan
- Scanner kamera memakai library browser CDN
- QR dibuat sebagai data URL, belum diekspor ke file PNG terpisah
- File gambar placeholder bawaan hanya contoh aman agar tidak 0B

